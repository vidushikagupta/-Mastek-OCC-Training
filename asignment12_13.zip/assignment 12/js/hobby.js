function ViewModel(){
    this.hobbies=ko.observable("Enter Hobbies");
}
const viewModel = new ViewModel();
ko.applyBindings(viewModel);
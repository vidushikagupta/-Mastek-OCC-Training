const express = require('express');
const server = express();
const port = 3000;
//get=>style.css
server.get('/css/style.css', (req, resp) => {
    resp.sendFile(__dirname + '/css/style.css');
});
//get=>app.js
server.get('/js/knockout.3.5.1.js', (req, resp) => {
    resp.sendFile(__dirname + '/js/knockout.3.5.1.js');
});
//get=>index.html
server.get('/index.html', (req, resp) => {
    resp.setHeader("Content-Type", "text/html")
    resp.sendFile(__dirname + '/index.html');
});
//start server to listen
server.listen(port, () => {
    console.log(`http://localhost:${port} started `);
})
// http://localhost:3000 must open index.html
server.get('/',(req,resp)=>{
    resp.setHeader("Content-Type","text/html")
    resp.sendFile(__dirname+'/index.html');
});
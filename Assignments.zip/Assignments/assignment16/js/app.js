const viewModel={

    currentProfit:ko.observable(12345.00)

}

viewModel.profitStatus=ko.pureComputed(function(){

    console.log(this.currentProfit);

    return this.currentProfit() < 0?"profitWarning":"profitPositive";

},viewModel);

ko.applyBindings(viewModel);
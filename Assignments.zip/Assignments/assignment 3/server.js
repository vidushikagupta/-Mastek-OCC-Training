const http = require('http');
const fs = require('fs')
const port = 3000;

http.createServer((req,resp)=>{
    const url = req.url;
    resp.setHeader("Content-Type", 'text/html');
    resp.write("Server is working on request");
    resp.write("<br/> Client is looking for " +url)
    resp.write("<br/><a href='index.html'></a>")
    if(url==="/index.html"){
        console.log("Reading index.html async mode");
        const fileName = __dirname+'/index.html';
        fs.readFile(fileName,(err,data)=>{
            if(err){
              resp.write("Error: "+err);
            }
            resp.write(data);
            resp.end();
        })
    }
}).listen(port,()=>{
    console.log(`Server listening : http://localhost:${port}`)
});
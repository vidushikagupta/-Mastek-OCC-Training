function add(){
    var num1 = parseInt(document.getElementById("n1").value);
    var num2 = parseInt(document.getElementById("n2").value);
    var num3;
    num3 = num1 + num2;
    document.getElementById("result").value = num3;
}
function sub(){
    var num1 = parseInt(document.getElementById("n1").value);
    var num2 = parseInt(document.getElementById("n2").value);
    var num3;
    num3 = num1 - num2;
    document.getElementById("result").value = num3;
}
function multiply(){
    var num1 = parseInt(document.getElementById("n1").value);
    var num2 = parseInt(document.getElementById("n2").value);
    var num3;
    num3 = num1 * num2;
    document.getElementById("result").value = num3;
}
function divide(){
    var num1 = parseInt(document.getElementById("n1").value);
    var num2 = parseInt(document.getElementById("n2").value);
    var num3;
    num3 = num1 / num2;
    document.getElementById("result").value = num3;
}
    
//server works on http protocol
//where is http protocol logic => node core module http
const http=require('http');
const port=3000;

http.createServer(function(req,resp){
    resp.write("welcome to node server");
    resp.end();
}).listen(port,function(){
    console.log(`Customer server is working at : http://localhost:${port}`);
});
function validate(event){
  const fname = document.forms["contact_form"]["firstName"];
  const lname = document.forms["contact_form"]["lastName"];
  const City = document.forms["contact_form"]["city"];

  if (fname.value == "") {
    window.alert("Please enter your first Name.");
    fname.focus();
    return false;
  }
  if (lname.value == "") {
    window.alert("Please enter your Last Name.");
    lname.focus();
    return false;
  }
  if (City.value == "") {
    window.alert("Please enter your city.");
    City.focus();
    return false;
  }
  return true;
}
